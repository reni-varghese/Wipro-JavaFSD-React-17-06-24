package org.reni.service;

import java.util.List;

import org.reni.exception.EmployeeNotFoundException;
import org.reni.model.Employee;
import org.reni.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeRepository repository;

	@Override
	public List<Employee> getAll() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public Employee getById(int id) {
		// TODO Auto-generated method stub
		return repository.findById(id).
				orElseThrow(()->new EmployeeNotFoundException("Employee with Id "+id+" does not exist"));
	}

	@Override
	public Employee addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return repository.save(employee);
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return repository.save(employee);
	}

	@Override
	public void deleteEmployee(int id) {
		repository.deleteById(id);
		

	}

}
