package org.reni.controller;

import java.util.List;

import org.reni.model.Employee;
import org.reni.service.EmployeeService;
import org.springframework.aot.hint.BindingReflectionHintsRegistrar;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
@Controller
public class EmployeeController {
	@Autowired
	private EmployeeService employeeService;
	@GetMapping("/")
	public String index(Model model) {
		
		List<Employee> employees = employeeService.getAll();
		model.addAttribute("employees", employees);
		return "index";
		
		
		
	}
	@GetMapping("/add")
	public String showAdd(Model model) {
		
		Employee employee=new Employee();
		model.addAttribute("employee",employee);
		return "add";
		
	}
	@PostMapping("/add-employee")
	public String addEmployee(@Valid Employee employee,BindingResult result) {
		if(result.hasErrors()) {
			return "add";
		}
		employeeService.addEmployee(employee);
		return "redirect:/";
	}
	@GetMapping("/update")
	public String showUpdate(@RequestParam int id,Model model) {
		
		Employee employee=employeeService.getById(id);
		model.addAttribute("employee", employee);
		return "update";
		
	}
	@PostMapping("/update-employee")
	public String updateEmployee(@Valid Employee employee,BindingResult result) {
		if(result.hasErrors()) {
			return "update";
		}
		employeeService.updateEmployee(employee);
		return "redirect:/";
		
	}
	
	@GetMapping("/delete")
	public String deleteEmployee(@RequestParam int id) {
		
		employeeService.deleteEmployee(id);
		return "redirect:/";
	}
	@GetMapping("/search")
	public String search(HttpServletRequest request,Model model) {
		int id=Integer.parseInt(request.getParameter("searchItem"));
		Employee emp=employeeService.getById(id);
		model.addAttribute("employee",emp);
		return "details";
		
	}
	
	

}
