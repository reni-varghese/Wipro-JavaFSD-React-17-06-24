package org.reni.controller;

import org.reni.exception.EmployeeNotFoundException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@ControllerAdvice
public class ErrorHandler {
	
	@ExceptionHandler(EmployeeNotFoundException.class)
	public String handleEmployeeNotFound(EmployeeNotFoundException ex,RedirectAttributes attributes) {
		attributes.addFlashAttribute("message", ex.getMessage());
		return "redirect:/";
		
	}

}
