package org.reni.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Employee {
	@Id
	private int id;
	@NotBlank(message="Employee Name cannot be blank")
	private String name;
	private String gender;
	@Min(value = 18,message = "Employee age should be between 18 and 60")
	@Max(value = 60,message = "Employee age should be between 18 and 60")
	private int age;
	private double salary;
}
