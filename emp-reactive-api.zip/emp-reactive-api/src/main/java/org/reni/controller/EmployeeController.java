package org.reni.controller;

import org.reni.model.Employee;
import org.reni.service.EmployeeService;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    private final EmployeeService employeeService;
    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }
    @GetMapping
    public Flux<Employee> getAllEmployees() {
        return employeeService.getEmployees();
    }

    @GetMapping("{id}")
    public Mono<Employee> getEmployee(@PathVariable int id) {
        return employeeService.getEmployee(id);
    }
    @PostMapping
    public Mono<ResponseEntity<Employee>> createEmployee(@RequestBody Employee employee) {

        return employeeService.createEmployee(employee).
                map(createdEmployee -> ResponseEntity.created(URI.create("/employees" + createdEmployee.getId()))
                        .body(createdEmployee));

    }

    @PutMapping("/{id}")
    public Mono<Employee> updateEmployee(@PathVariable int id, @RequestBody Employee employee) {
        return employeeService.updateEmployee(id,employee);
    }

    @DeleteMapping("/{id}")
    public Mono<Void> deleteEmployee(@PathVariable int id) {
        return employeeService.deleteEmployee(id);
    }


}
