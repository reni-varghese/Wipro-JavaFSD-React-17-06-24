package org.reni.service;

import org.reni.exception.EmployeeNotFoundException;
import org.reni.model.Employee;
import org.reni.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.function.Function;

@Service
public class EmployeeServiceImpl implements EmployeeService {


    private  EmployeeRepository employeeRepository;

    public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }


    @Override
    public Flux<Employee> getEmployees() {
        return employeeRepository.findAll().log();
    }

    @Override
    public Mono<Employee> getEmployee(int id) {
        return employeeRepository.findById(id)
                .switchIfEmpty(Mono.error(new EmployeeNotFoundException("Employee with id "+id+" does not exist")));
    }

    @Override
    public Mono<Employee> createEmployee(Employee employee) {

        return employeeRepository.save(employee);
    }

    @Override
    public Mono<Employee> updateEmployee(int id, Employee employee) {

        Mono<Employee> employeeMono=employeeRepository.findById(id).switchIfEmpty
                (Mono.error(new EmployeeNotFoundException("Employee with id "+id+" does not exist")));

        var updatedEmployee=employeeMono.map(emp->{
            if(employee.getName()!=null){
                emp.setName(employee.getName());
            }
            if(employee.getGender()!=null){
                emp.setGender(employee.getGender());
            }
            if(employee.getAge()!=0){
                emp.setAge(employee.getAge());
            }
            if(employee.getSalary()!=0){
                emp.setSalary(employee.getSalary());
            }
            return employeeRepository.save(emp);
        });

        return updatedEmployee.flatMap(Function.identity());



    }

    @Override
    public Mono<Void> deleteEmployee(int id) {
        employeeRepository.findById(id).switchIfEmpty
                (Mono.error(new EmployeeNotFoundException("Employee with id "+id+" does not exist")));
        return employeeRepository.deleteById(id);
    }
}
