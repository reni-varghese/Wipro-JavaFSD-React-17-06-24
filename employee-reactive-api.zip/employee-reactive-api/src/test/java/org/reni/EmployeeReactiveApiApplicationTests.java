package org.reni;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeReactiveApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
