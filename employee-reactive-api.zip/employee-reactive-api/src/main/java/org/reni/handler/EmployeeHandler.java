package org.reni.handler;

import org.reni.model.Employee;
import org.reni.service.EmployeeService;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

import static org.springframework.web.reactive.function.server.ServerResponse.*;

@Component
public class EmployeeHandler {

    private EmployeeService employeeService;

    public EmployeeHandler(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    public Mono<ServerResponse> getAllEmployees(ServerRequest request) {

        return ok().body(employeeService.getEmployees(), Employee.class);

    }
    public Mono<ServerResponse> getById(ServerRequest request) {
        int id=Integer.parseInt(request.pathVariable("id"));
        return ok().body(employeeService.getEmployee(id), Employee.class);

    }
    public Mono<ServerResponse> createEmployee(ServerRequest request) {
        return request.bodyToMono(Employee.class)
                .flatMap(employeeService::createEmployee)
                .flatMap(emp->created(request.uriBuilder().path("/{id}").build(emp.getId()))
                        .bodyValue(emp));
    }

    public Mono<ServerResponse> updateEmployee(ServerRequest request) {
        int id=Integer.parseInt(request.pathVariable("id"));
        return request.bodyToMono(Employee.class)
                .flatMap(emp->employeeService.updateEmployee(id,emp))
                .flatMap(e->ok().bodyValue(e));
    }

    public Mono<ServerResponse> deleteEmployee(ServerRequest request) {
        int id=Integer.parseInt(request.pathVariable("id"));
        return employeeService.deleteEmployee(id)
                .then(noContent().build());
    }

}
