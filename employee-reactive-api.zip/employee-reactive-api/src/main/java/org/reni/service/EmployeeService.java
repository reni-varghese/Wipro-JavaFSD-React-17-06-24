package org.reni.service;

import org.reni.model.Employee;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface EmployeeService {
    Flux<Employee> getEmployees();
    Mono<Employee> getEmployee(int id);
    Mono<Employee> createEmployee(Employee employee);
    Mono<Employee> updateEmployee(int id,Employee employee);
    Mono<Void> deleteEmployee(int id);
}
