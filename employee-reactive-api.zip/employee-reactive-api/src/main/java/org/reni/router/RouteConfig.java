package org.reni.router;

import org.reni.handler.EmployeeHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.relational.core.sql.Delete;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import static org.springframework.web.reactive.function.server.RequestPredicates.*;
import static org.springframework.web.reactive.function.server.RouterFunctions.route;

@Configuration
public class RouteConfig {
    @Bean
    RouterFunction<ServerResponse> routes(EmployeeHandler employeeHandler){

//        return route().GET("/api/employees",employeeHandler::getAllEmployees)
//                .GET("/api/employees/{id}",employeeHandler::getById)
//                .POST("/api/employees",employeeHandler::createEmployee)
//                .PUT("/api/employees/{id}",employeeHandler::updateEmployee)
//                .DELETE("/api/employees/{id}",employeeHandler::deleteEmployee)
//                .build();

        return RouterFunctions.nest(path("/api/employees"),
                route(GET(""),employeeHandler::getAllEmployees)
                        .andRoute(POST(""),employeeHandler::createEmployee)
                        .andRoute(GET("/{id}"),employeeHandler::getById)
                        .andRoute(PUT("/{id}"),employeeHandler::updateEmployee)
                        .andRoute(DELETE("/{id}"),employeeHandler::deleteEmployee));





    }


}
