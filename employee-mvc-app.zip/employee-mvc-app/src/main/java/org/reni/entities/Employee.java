package org.reni.entities;

import org.hibernate.validator.constraints.NotEmpty;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Employee {
	@Id
	private int id;
	@NotBlank(message = "Employee Name cannot be blank")
	@Pattern(regexp = "[A-Za-z\s]+",message = "Employee Name should contain only alphabets")
	private String name;
	private String gender;
	@Min(value=18,message="Employee Age should be between 18 and 60")
	@Max(value=60,message="Employee Age should be between 18 and 60")
	private int age;
	private double salary;
}
