package org.reni.controller;

import java.util.List;

import org.reni.entities.Employee;
import org.reni.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@Controller
public class EmployeeController {
	@Autowired
	private EmployeeService service;
	@GetMapping("/")
	public ModelAndView showIndex() {
		
		List<Employee> employees=service.getAllEmployees();
		ModelAndView mv=new ModelAndView("index");
		mv.addObject("employees",employees);
		return mv;
	}
	@GetMapping("/show-addform")
	public String showAdd(Model model) {
		
		Employee employee=new Employee();
		model.addAttribute("employee", employee);
		
		return "add";
		
	}
	@PostMapping("/add-employee")
	public String addEmployee(@Valid @ModelAttribute Employee employee,BindingResult result) {
		if(result.hasErrors()) {
			return "add";
		}
		service.addEmployee(employee);
		return "redirect:/";
		
	}
	@GetMapping("/update")
	public String showUpdate(@RequestParam("id") int id,Model model) {
		
		Employee employeee=service.getById(id);
		
		model.addAttribute("employee",employeee);
		return "update";
		
		
	}
	@PostMapping("/update-employee")
	public String updateEmployee(@Valid @ModelAttribute Employee employee,BindingResult result) {
		if(result.hasErrors()) {
			return "update";
		}
		service.updateEmployee(employee);
		return "redirect:/";
		
	}
	@GetMapping("/delete")
	public String deleteEmployee(@RequestParam("id") int id) {
		
		service.deleteEmployee(id);
		return "redirect:/";
		
	}
	@GetMapping("/search")
	public String search(HttpServletRequest request,Model model) {
		
		int id=Integer.parseInt(request.getParameter("searchItem"));
		Employee emp=service.getById(id);
		model.addAttribute("employee",emp);
		return "details";
	}
	@GetMapping("/ind")
	public String ind() {
		
		return "redirect:/";
	}
	

}
