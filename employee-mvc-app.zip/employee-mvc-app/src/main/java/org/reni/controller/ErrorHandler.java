package org.reni.controller;

import org.reni.exceptions.EmployeeNotFoundException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import jakarta.servlet.http.HttpSession;

@ControllerAdvice
public class ErrorHandler {
	@ExceptionHandler(EmployeeNotFoundException.class)
	public String handleEmployeeNotFound(EmployeeNotFoundException ex, HttpSession session) {
		
		session.setAttribute("message", ex.getMessage());
		
		return "redirect:/";
		
	}

}
