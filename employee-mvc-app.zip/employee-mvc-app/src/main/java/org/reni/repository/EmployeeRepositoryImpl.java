package org.reni.repository;

import java.util.List;

import org.hibernate.Session;
import org.reni.entities.Employee;
import org.reni.exceptions.EmployeeNotFoundException;
import org.springframework.stereotype.Repository;

import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
@Repository
public class EmployeeRepositoryImpl implements EmployeeRepository {
	
	@PersistenceContext
	private Session session;

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		TypedQuery<Employee> query=session.createQuery("from Employee",Employee.class);
		List<Employee> employees=query.getResultList();
		return employees;
	}

	@Override
	public Employee getById(int id) {
		Employee employee=session.find(Employee.class, id);
		if(employee==null) {
			throw new EmployeeNotFoundException("Employee with id "+id+" does not exist");
		}
		
		
		return employee;
	}

	@Override
	public String addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		
		session.persist(employee);
		
		return "Employee addes successfully";
	}

	@Override
	public String updateEmployee(Employee employee) {
		Employee emp=session.find(Employee.class, employee.getId());
		emp.setName(employee.getName());
		emp.setGender(employee.getGender());
		emp.setAge(employee.getAge());
		emp.setSalary(employee.getSalary());
		
		return "Employee updated successfully";
	}

	@Override
	public String deleteEmployee(int id) {
		Employee employee=session.find(Employee.class, id);
		session.remove(employee);
		return "Employee deleted successfully";
	}

}
