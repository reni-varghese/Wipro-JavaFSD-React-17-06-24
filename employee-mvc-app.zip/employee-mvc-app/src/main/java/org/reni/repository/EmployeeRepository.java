package org.reni.repository;

import java.util.List;

import org.reni.entities.Employee;

public interface EmployeeRepository {

	List<Employee> getAllEmployees();
	Employee getById(int id);
	String addEmployee(Employee employee);
	String updateEmployee(Employee employee);
	String deleteEmployee(int id);
}
