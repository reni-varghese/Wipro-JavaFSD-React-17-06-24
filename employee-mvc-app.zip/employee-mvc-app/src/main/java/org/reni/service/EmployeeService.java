package org.reni.service;

import java.util.List;

import org.reni.entities.Employee;

public interface EmployeeService {
	List<Employee> getAllEmployees();
	Employee getById(int id);
	String addEmployee(Employee employee);
	String updateEmployee(Employee employee);
	String deleteEmployee(int id);
}
