package org.reni.service;

import java.util.List;

import org.reni.entities.Employee;
import org.reni.repository.EmployeeRepository;
import org.reni.repository.EmployeeRepositoryImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository repository;
	
	
	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return repository.getAllEmployees();
	}

	@Override
	public Employee getById(int id) {
		// TODO Auto-generated method stub
		return repository.getById(id);
	}

	@Override
	public String addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return repository.addEmployee(employee);
	}

	@Override
	public String updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return repository.updateEmployee(employee);
	}

	@Override
	public String deleteEmployee(int id) {
		// TODO Auto-generated method stub
		return repository.deleteEmployee(id);
	}

}
